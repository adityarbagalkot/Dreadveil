# Darius Forgeward — approved artwork package

These are the user-approved artwork previews prepared for the Dreadveil character UI. They are delivered as compressed JPEGs to make transfer easier; the generated originals were PNGs.

## Files
- `assets/full-body/darius-forgeward-full-body.jpg` — approved full-body illustration (1536×1024).
- `assets/portrait/darius-forgeward-portrait.jpg` — approved portrait-oriented roster portrait (1024×1536).
- `assets/ability/forgeguard-icon.jpg` — the approved painterly animal-face direction for Forgeguard (1024×1536).

## Canonical profile check
- Name: Darius Forgeward
- Title: The Forgeguard
- Hybrid: Rhinoceros × Badger × Tortoise
- Weapon: Anvil maul
- HP: 44
- Cooldown: 3
- Ability: Forgeguard — Gain 10 Guard. If the current attack damages Darius, scorch the attacker for 3 damage.

The images are visual assets only. The character values above must remain sourced from `rules/characters/character-data.json`. Generated lettering or extra lore is not authoritative.

## Repository placement
Copy the `assets/` folder contents into `character-ui/characters/darius-forgeward/assets/` in the Dreadveil repository. The GitHub connector available in this session supports text-file commits but does not expose binary image upload, so this package is prepared locally rather than falsely reported as committed to GitHub.
